<?php
// Heading
$_['heading_title']    = 'Per Item';

// Text
$_['text_description'] = 'Per Item Shipping Rate';